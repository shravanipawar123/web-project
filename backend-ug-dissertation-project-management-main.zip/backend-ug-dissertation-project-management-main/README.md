
# UG Dissertation Management System

<h3>Project created using Nodejs Express</h3>


## Installation

Install with npm

```bash
git clone backend-ug-dissertation-project-management


cd backend-ug-dissertation-project-management

npm install 
```
    
