function Footer() {
  return <div>HELLO World</div>;
}
export default Footer;
